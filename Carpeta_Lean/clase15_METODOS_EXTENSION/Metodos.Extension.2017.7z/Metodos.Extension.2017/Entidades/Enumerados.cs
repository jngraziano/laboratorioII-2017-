﻿namespace Entidades
{
    public enum ESexo
    {
        Femenino,
        Masculino,
        Indefinido
    }
}