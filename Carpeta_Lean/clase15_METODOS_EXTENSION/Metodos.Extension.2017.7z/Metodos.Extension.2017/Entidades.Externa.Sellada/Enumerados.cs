﻿namespace Entidades.Externa.Sellada
{
    public enum ESexo
    {
        Femenino,
        Masculino,
        Indefinido
    }
}