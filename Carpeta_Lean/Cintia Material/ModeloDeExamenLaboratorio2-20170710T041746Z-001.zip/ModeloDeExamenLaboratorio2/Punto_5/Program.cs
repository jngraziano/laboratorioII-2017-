﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto_5
{
    class Program
    {
        static void Main(string[] args)
        {
            //5.Realizar una interfase que posea un metodo que retornara un objeto producto y reciba un entero 
            //y una propiedad de solo lectura que retornara un producto
        }
    }


}
