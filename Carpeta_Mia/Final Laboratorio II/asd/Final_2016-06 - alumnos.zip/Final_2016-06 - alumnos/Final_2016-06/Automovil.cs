﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Automovil : Vehiculo, ISerializable //quitar herencia
    {
        private static string MENSAJE_ERROR_ARCHIVO_GUARDAR = "Error al guardar el archivo.";
        private static string MENSAJE_ERROR_ARCHIVO_LEER = "Error al leer el archivo.";

        #region Constructores
        public Automovil(EMarca marca, string patente, ConsoleColor color)
            : base(patente, marca, color)
        {
        }
        #endregion

        #region Propiedades
        /// <summary>
        /// Los automoviles tienen 4 ruedas
        /// </summary>
        protected override short CantidadRuedas
        {
            get
            {
                return 4;
            }
        }
        
        #endregion

        public override sealed string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("AUTOMOVIL");
            sb.Append(base.Mostrar());
            sb.AppendFormat("RUEDAS : {0}", this.CantidadRuedas);
            sb.AppendLine("");
            sb.AppendLine("---------------------");

            return sb;
        }

        #region Serialización

        public void leer(string archivo, out Automovil datos)
        {
        }

        #endregion
    }
}
